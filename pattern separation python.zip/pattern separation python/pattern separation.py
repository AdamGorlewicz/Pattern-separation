# -------------path to the matlab file with data-------------

data_file = r"C:\Users\agorlewicz\Desktop\Pattern separation python\example data\rat.mat"

# -------------output folder-------------

output_folder = r"C:\Users\agorlewicz\Desktop\Pattern separation python\result"

# -------------stimulation-------------

stim = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch59"

# -------------cells-------------

cell1 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch201"
cell2 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch209"
cell3 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch210"
cell4 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch214"
cell5 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch215"
cell6 = "V2024_05_15T15_21_14vDG_horizontal_2_sorted_Ch234"

# -------------include cells for analysis-------------

cells = [cell1, cell2, cell3, cell4, cell5, cell6]
names = ['cell1', 'cell2', 'cell3', 'cell4', 'cell5', 'cell6']

# -------------inputsets names-------------

inputsets_names = ['inputset ~025', 'inputset ~045', 'inputset ~075', 'inputset ~095']

# -------------stimmulation start points [s]-------------

inputset_025_start = []
inputset_045_start = []
inputset_075_start = []
inputset_095_start = []

# repetition 1
inputset_095_start.append(764.883) 
inputset_075_start.append(2044.234)
inputset_045_start.append(179.553)
inputset_025_start.append(1392.920)
# repetition 2
inputset_095_start.append(815.836)
inputset_045_start.append(239.481)
inputset_075_start.append(2044.236)
inputset_025_start.append(1469.001)
# repetition 3
inputset_095_start.append(866.829)
inputset_045_start.append(294.322)
inputset_075_start.append(2170.335)
inputset_025_start.append(1565.3158)
# repetition 4
inputset_095_start.append(921.726)
inputset_045_start.append(345.691)
inputset_075_start.append(2225.639)
inputset_025_start.append(1617.6114)
# repetition 5
inputset_095_start.append(979.519)
inputset_045_start.append(397.045)
inputset_075_start.append(2276.976)
inputset_025_start.append(1676.325)
# repetition 6
inputset_095_start.append(1037.145)
inputset_045_start.append(452.662)
inputset_075_start.append(2329.665)
inputset_025_start.append(1783.807)
# repetition 7
inputset_095_start.append(1097.338)
inputset_045_start.append(504.446)
inputset_075_start.append(2381.091)
inputset_025_start.append(1783.807)
# repetition 8
inputset_095_start.append(1164.547)
inputset_045_start.append(571.967)
inputset_075_start.append(2452.748)
inputset_025_start.append(1839.665)
# repetition 9
inputset_095_start.append(1217.420)
inputset_045_start.append(623.393)
inputset_075_start.append(2505.892)
inputset_025_start.append(1896.881)
# repetition 10
inputset_095_start.append(1281.029)
inputset_045_start.append(675.297)
inputset_075_start.append(2562.389)
inputset_025_start.append(1948.322)

inputsets_start = [inputset_025_start, inputset_045_start, inputset_075_start, inputset_095_start]


# -------------DO NOT CHANGE BELOW THIS LINE-------------

# -------------importing modules-------------

import mat73 as matload
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# -------------defining functions-------------

def plot_data(no_cells, mat_data, stim_times, response_times, output_folder, file_name):
# this function plots experimental data and saves figure
    for i in range(no_cells):
        response_times[i] = np.array(mat_data[cells[i]]['times'])
    data_for_plotting = [None] * (no_cells+1)
    for i in range(no_cells):
        data_for_plotting[i] = response_times[i]
    data_for_plotting[no_cells] = stim_times
    maximum = []
    for i in data_for_plotting:
        maximum.append(max(i))
    recording_time = round(max(maximum)+100)
    colorCodes = np.array([0, 0, 0])
    fig, axes = plt.subplots(figsize=(14, 3))
    axes.eventplot(data_for_plotting, orientation="horizontal", lineoffsets=[1], linewidth=1, linelengths=0.8, color=colorCodes)
    axes.grid(False)
    axes.spines['top'].set_visible(False)
    axes.spines['left'].set_visible(False)
    axes.spines['right'].set_visible(False)
    axes.set(xlim=(0, recording_time), ylim=(-1, no_cells+1), yticks=[])
    axes.set_title('data rasters', fontsize=10)
    axes.set_xlabel(u" time [s]", fontsize=10)
    axes.tick_params(axis='y', colors='black', labelcolor ='black', width=0)
    axes.set_yticks(list(range(0, no_cells+1)))
    ylabels = names + ['stimulation']
    axes.set_yticklabels(ylabels)
    fig.savefig(output_folder + '\\' + file_name + '.tif', dpi=300, bbox_inches="tight")
    plt.close()
    
def plot_inputsets_raster(inputsets,output_folder,file_name):
# this function plots inputsets and saves figures    
    #colorCodes = np.array(['#bfd3e6', '#9ebcda', '#8c96c6', '#8856a7', '#810f7c']) 
    colorCodes = np.array(['#fee391', '#fec44f', '#fe9929', '#d95f0e', '#993404']) 
    fig, axes = plt.subplots()   
    axes.grid(False)
    axes.spines['top'].set_visible(False)
    axes.spines['right'].set_visible(False)
    axes.spines['left'].set_visible(False)
    axes.set(xlim=(0, 2), ylim=(0, 6), xticks=[0,0.25,0.5,0.75,1,1.25,1.5,1.75,2], yticks=[0,1,2,3,4,5,6])
    axes.set_xticklabels([0,0.25,0.5,0.75,1,1.25,1.5,1.75,2], fontsize=10)
    axes.set_yticklabels(['', 1, 2, 3, 4, 5, ''], fontsize=10)
    axes.tick_params(axis='y', colors='black', labelcolor ='black', width=0)
    axes.set_title('', y=1.10, fontsize=10)
    axes.set_ylabel(u"# input train", fontsize=10)
    axes.set_xlabel(u"time [s]", fontsize=10)
    axes.set_title(file_name, fontsize=10)
    for no_repetition in range(10):     
        axes.eventplot(inputsets[no_repetition], orientation="horizontal", lineoffsets=[1,2,3,4,5], linewidth=1, linelengths = 0.8, color=colorCodes)  
        fig.savefig(output_folder + '\\' + file_name + ' repetition ' + str(no_repetition+1) + ' raster.tif', dpi=300, bbox_inches="tight")
        plt.close()
        
def plot_inputsets_matrix(data,output_folder,file_name):  
    # this function bins datasets into 1 ms bins and creates correlation matrices
    for no_repetition in range(10):
        time_bins=np.linspace(0.01,2.01,200,endpoint=False)
        histogram = []
        fig, axes = plt.subplots()
        fig.suptitle('', fontsize =10)
        fig.subplots_adjust(wspace = 0.5)
        colormap = sns.color_palette("YlOrBr", as_cmap=True)
        #colormap = sns.color_palette("BuPu", as_cmap=True)
        for i in range(5):
            hist, bins = np.histogram(data[no_repetition][i], bins=time_bins)
            histogram.append(hist)
        R = np.corrcoef(histogram)
        R2 = np.tril(R, k=-1)
        R2[R2  == 0] = 'nan'
        Rmean = str(round(np.nanmean(R2),2))
        sns.heatmap(R, cmap=colormap, vmax=1, vmin=0, center=0.5, square=True, linewidths=0.5, ax=axes, cbar_kws={"shrink": .5, 'label': 'corr. (R)'})
        axes.set_title(file_name + '\nR = ' + Rmean, y=1.10, fontsize=10)
        axes.set_ylabel(u"# input train", fontsize=10)
        axes.set_xlabel(u"# input train", fontsize=10)
        axes.set_xticklabels([1,2,3,4,5])
        axes.set_yticklabels([1,2,3,4,5])
        axes.tick_params(axis='x', width=0, colors='black', labelcolor ='black')
        axes.tick_params(axis='y', width=0, colors='black', labelcolor ='black', rotation = 0)
        axes.spines['right'].set_visible(False)
        axes.spines['top'].set_visible(False)
        fig.savefig(output_folder + '\\' + file_name + ' repetition ' + str(no_repetition+1) + ' matrix.tif', dpi=300, bbox_inches="tight")
        plt.close()
        
def plot_datasets_raster(datasets,output_folder,file_name):
   # this function plots datasetssets and saves figures 
   # colorCodes = np.array(['#bfd3e6', '#9ebcda', '#8c96c6', '#8856a7', '#810f7c', 
   #'0#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', '#bfd3e6', 
   #'#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda', '#9ebcda',
   #'#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', '#8c96c6', 
   #'#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', '#8856a7', 
   #'#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c', '#810f7c']) 

    colorCodes = np.array(['#fee391', '#fec44f', '#fe9929', '#d95f0e', '#993404',
   '#fee391', '#fee391', '#fee391', '#fee391', '#fee391', '#fee391', '#fee391', '#fee391', '#fee391', '#fee391',                        
   '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f', '#fec44f',
   '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929', '#fe9929',
   '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e', '#d95f0e',
   '#993404', '#993404', '#993404', '#993404', '#993404', '#993404', '#993404', '#993404', '#993404', '#993404'])
    
    fig, axes = plt.subplots()   
    axes.grid(False)
    axes.spines['top'].set_visible(False)
    axes.spines['right'].set_visible(False)
    axes.spines['left'].set_visible(False)
    axes.set(xlim=(0, 2), ylim=(-1, 55), xticks=[0,0.25,0.5,0.75,1,1.25,1.5,1.75,2], yticks=[2,10,20,30,40,50])
    axes.set_xticklabels([0,0.25,0.5,0.75,1,1.25,1.5,1.75,2], fontsize=10)
    axes.set_yticklabels(['input', '#1', '#2', '#3', '#4', '#5'], fontsize=10)
    axes.tick_params(axis='y', colors='black', labelcolor ='black', width=0)
    axes.set_title(file_name, y=1.10, fontsize=10)
    axes.set_ylabel(u"output subsets", fontsize=10)
    axes.set_xlabel(u"time [s]", fontsize=10)
    axes.eventplot(datasets, orientation="horizontal", linewidth=1, linelengths = 0.8, color=colorCodes)
    axes.invert_yaxis()
    fig.savefig(output_folder + '\\' + file_name + ' raster.tif', dpi=300, bbox_inches="tight")
    plt.close()
    
def plot_datasets_matrix(datasets,output_folder,file_name):  
    # this function bins datasets into 1 ms bins and creates correlation matrices
    time_bins=np.linspace(0.01,2.01,200,endpoint=False)
    histogram = []
    for i in range(55):
        hist, bins = np.histogram(datasets[i], bins=time_bins)
        histogram.append(hist)
    R = np.corrcoef(histogram)
    R2 = np.tril(R[5:, 5:], k=-1)
    R2[R2  == 0] = 'nan'
    Rmean = str(round(np.nanmean(R2),2))
    fig, axes = plt.subplots()
    fig.suptitle('', fontsize =10)
    fig.subplots_adjust(wspace = 0.5)
    colormap = sns.color_palette("YlOrBr", as_cmap=True)
    #colormap = sns.color_palette("BuPu", as_cmap=True)
    sns.heatmap(R, cmap=colormap, vmax=1, vmin=0, center=0.5, square=True, linewidths=0, ax=axes, cbar_kws={"shrink": .5, 'label': 'corr. (R)'})
    axes.tick_params(axis='x', width=0, colors='black', labelcolor ='black', rotation = 0)
    axes.tick_params(axis='y', width=0, colors='black', labelcolor ='black', rotation = 0)
    axes.set(xticks=[2,10,20,30,40,50], yticks=[2,10,20,30,40,50])
    axes.set_xticklabels(['input', '#1', '#2', '#3', '#4', '#5'], fontsize=10)
    axes.set_yticklabels(['input', '#1', '#2', '#3', '#4', '#5'], fontsize=10)
    axes.tick_params(width=0)
    axes.tick_params(axis='x', colors='black', labelcolor ='black')
    axes.spines['right'].set_visible(False)
    axes.spines['top'].set_visible(False)
    axes.set_title(file_name + '\nR = ' + Rmean, y=1.10, fontsize=10)
    axes.set_ylabel(u"# output subsets", fontsize=10)
    axes.set_xlabel(u"# output subsets", fontsize=10)
    fig.savefig(output_folder + '\\' + file_name + ' matrix.tif', dpi=300, bbox_inches="tight")
    plt.close()
    pd.DataFrame(R).to_excel(output_folder + '\\' + file_name + ' corrcoef.xlsx', sheet_name='corrcoef')     
    return Rmean
    
def save_results(mean_corrcoef):
    # this function builds tebel with results and saves it into excel file    
    #result_table = pd.DataFrame(mean_corrcoef)
    mean_corrcoef.to_excel(output_folder + '\\' + 'input output correlation.xlsx', sheet_name='correlation')
    mean_corrcoef_2 = pd.read_excel(output_folder + '\\' + 'input output correlation.xlsx', index_col=0)   
    mean_corrcoef_2 = mean_corrcoef_2.drop(np.nan)  
    mean_corrcoef_2.to_excel(output_folder + '\\' + 'input output correlation.xlsx', sheet_name='correlation')        
 
# -------------loading and plotting matlab data-------------

no_cells = len(cells)
mat_data = matload.loadmat(data_file)
stim_times = np.array(mat_data[stim]['times'])
response_times = list(range(no_cells))
plot_data(no_cells, mat_data, stim_times, response_times, output_folder, 'protocol raster')

# -------------creating input sets-------------

interval = 7.0031
length = 2

inputsets = [[[[],[],[],[],[]] for i in range(10)] for i in range(4)]

for no_repetition in range(10):
    for no_inputset in range(4):
        for no_trace  in range(5):
            inputsets[no_inputset][no_repetition][no_trace] = [item0 for item0 in stim_times if item0 > inputsets_start[no_inputset][no_repetition] + (interval * (no_trace)) and item0 < inputsets_start[no_inputset][no_repetition] + (interval*(no_trace))+length] 
            
for no_repetition in range(10):
    for no_inputset in range(4):
        for no_trace  in range(5):
            inputsets[no_inputset][no_repetition][no_trace] = [x - (inputsets_start[no_inputset][no_repetition] + (interval * (no_trace))) for x in inputsets[no_inputset][no_repetition][no_trace]]

# -------------plotting inputsets (rasterplot)-------------

for no_inputset in range(4):    
    plot_inputsets_raster(inputsets[no_inputset],output_folder, inputsets_names[no_inputset])     
    plot_inputsets_matrix(inputsets[no_inputset],output_folder, inputsets_names[no_inputset])

# -------------building datasets-------------

no_repetition = 0

datasets = [[[[[]] for i in range(55)] for j in range(4)] for n in range(no_cells)]

for no_cell in range(no_cells):
    for no_inputset in range(4):
       for no_trace  in range(5):
           datasets[no_cell][no_inputset][no_trace] = inputsets[no_inputset][no_repetition][no_trace]
           
for no_cell in range(no_cells):
    for no_inputset in range(4):
        for no_repetition in range(10):
            for no_trace  in range(5):
                datasets[no_cell][no_inputset][no_trace+5+(5*no_repetition)] = [item0 for item0 in response_times[no_cell] if item0 > inputsets_start[no_inputset][no_repetition] + (interval * (no_trace)) and item0 < inputsets_start[no_inputset][no_repetition] + (interval*(no_trace))+length] 

for no_cell in range(no_cells):
    for no_repetition in range(10):
        for no_inputset in range(4):
            for no_trace  in range(5):
                datasets[no_cell][no_inputset][no_trace+5+(5*no_repetition)] = [x - (inputsets_start[no_inputset][no_repetition] + (interval * (no_trace))) for x in datasets[no_cell][no_inputset][no_trace+5+(5*no_repetition)]]
           
# -------------plotting datasets and calculating correlation coefficients-------------

mean_corrcoef = [ [[] for i in range(4)] for i in range(no_cells)]

for no_cell in range(no_cells):
    for no_inputset in range(4):
        plot_datasets_raster(datasets[no_cell][no_inputset],output_folder,'dataset cell ' + str(no_cell+1) + ' ' + inputsets_names[no_inputset])
        mean_corrcoef[no_cell][no_inputset] = plot_datasets_matrix(datasets[no_cell][no_inputset],output_folder,'dataset cell ' + str(no_cell+1) + ' ' + inputsets_names[no_inputset])
mean_corrcoef = pd.DataFrame(mean_corrcoef)
mean_corrcoef.index = [names]
mean_corrcoef.columns = [inputsets_names]

# -------------saving results-------------

save_results(mean_corrcoef)